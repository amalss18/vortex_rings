Conditions for simulation
rankine_6_periodic : nu=1e-6 , r=1, a=0.2, f=2, x2.5, y2, z2, no boundary, dx=0.25, tf = 1, dt=1e-4
rankine_7_periodic: above,tf=3, gamma =0.075
rankine_7_periodic_2: above,tf=3, gamma =0.75
rankine_7_periodic_3: above,dt=1e-4,tf=3, gamma =0.75, with boundary
rankine_periodic_8: 7_periodic_2, gamma = 0.0075, dt = 1e-3, f=1.5, 
start_over : gamma = 0.0075, Rcore=0.3, r=1.5, f=2.5, periodic, 
start_over_2 : start_over, 0.075 
